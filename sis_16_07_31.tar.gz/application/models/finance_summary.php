<?php

class finance_summary extends MY_Model{
    const DB_TABLE = 'finance_summary';
    const DB_TABLE_PK = 'type_id';
    
    public $type_id;
    
    public $type_name;
    
    public $academic_year;
    
    public $amount;
    
    public $is_expense;
    
    public function amount_polarity()
    {
        return $this->is_expense < 1 ? $this->amount : $this->amount * -1;
    }
    
    public function get_finance_summary($academic_year)
    {
        $sql = "SELECT *  FROM finance_summary WHERE academic_year = '$academic_year' ORDER BY is_expense";
        $query = $this->db->query($sql);        
        $summaries = array();        
        foreach($query->result() as $row)
        {
            $summaries[$row->type_id] = $row;
        }
        
        //let's get all remaining collection types
        $sql2 = "SELECT * FROM collection_types WHERE type_id NOT IN (";
        foreach ($summaries as $s)
        {
            $sql2 .= $s->type_id . ',';
        }        
        $sql2 .= ') and is_deleted = 0';        
        $finalSQL = str_replace(',)', ')', $sql2);
        $query2 = $this->db->query($finalSQL);  
                
        foreach($query2->result() as $collection_type)
        {
            $fn_summary = new finance_summary();
            $fn_summary->type_id = $collection_type->type_id;
            $fn_summary->academic_year = $academic_year;
            $fn_summary->amount = 0;
            $fn_summary->type_name = $collection_type->type_name;
            $fn_summary->is_expense = $collection_type->is_expense;
            
            $summaries[$fn_summary->type_id] = $fn_summary;
        }
        
        return $summaries;
    }
    
    public function get_all_finance_summaries()
    {
        $academic_year = new Academic_year();
        $years = $academic_year->get_all_academic_years();
        $finance_summaries = array();
        foreach($years as $year)
        {
            $summary = $this->get_finance_summary($year);
            $summary['academic_year'] = $year;
            $finance_summaries[$year] = $summary;
        }
        return $finance_summaries;
    }
}
