<?php

//class Student_Class extends My_Model{
//    
//    const DB_TABLE = 'student_classes';
//    const DB_TABLE_PK = 'student_class_id';
//    
//    public $student_class_id;
//    
//    public $student_id;
//    
//    public $level_id;
//    
//    public $academic_year;
//    
//    public $fees_due;
//}

