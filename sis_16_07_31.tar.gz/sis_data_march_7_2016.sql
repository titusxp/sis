-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2016 at 12:46 PM
-- Server version: 5.5.45-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sis_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `ip_address` varchar(45) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `user_agent` varchar(120) COLLATE latin1_general_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('0446dbbe7a4b0e46597d54f6bf2555f7', '184.168.224.230', 'Ruby', 1456187185, ''),
('1b52c39ff4e8ab756cbbbbda00965f44', '184.168.224.190', 'Ruby', 1457225209, ''),
('1fc9208c93b9bc57c16350e7d7fdca60', '184.168.224.230', 'Ruby', 1454985356, ''),
('22fdba69837b65f6e658874678ff5c45', '184.168.224.230', 'Ruby', 1456100645, ''),
('3cf0d1d0d9f64b2f42c1e7cdec4eb333', '184.168.224.230', 'Ruby', 1455587148, ''),
('46fa03b01d23d38928d909286414ca16', '184.168.224.231', 'Ruby', 1455928125, ''),
('50897b4204d94c97b90cdad1ed1a4df0', '184.168.224.231', 'Ruby', 1456969710, ''),
('5d5baad0b9950c5ad5b764131ef03644', '184.168.224.230', 'Ruby', 1455411105, ''),
('5e60286c0d59cb35a80629de1f8f3657', '184.168.224.191', 'Ruby', 1457311268, ''),
('6b92387b377094a6cb54567c82ddc12a', '184.168.224.230', 'Ruby', 1457058234, ''),
('78e45062328a37e3d27ef09c998865c1', '184.168.224.230', 'Ruby', 1455497915, ''),
('7ba30c3008743bb6edf78138fafb26a9', '184.168.224.229', 'Ruby', 1456795868, ''),
('80c609e937afde6d3d8a6e60418b719e', '184.168.224.139', 'Ruby', 1455071953, ''),
('85a87be4556321ae1fcb9130f88fa953', '184.168.224.230', 'Ruby', 1456015361, ''),
('87ab5a80b00b6fe98d4173b6e11370fd', '184.168.224.231', 'Ruby', 1455155395, ''),
('a0bf816ef518d384fa0031722ab776dc', '184.168.224.190', 'Ruby', 1455330862, ''),
('a574c17a6903f18c73632ee2479bda6c', '184.168.224.191', 'Ruby', 1456534025, ''),
('ae61f0aa144b0723ea39f91160caf5ba', '184.168.224.190', 'Ruby', 1457138468, ''),
('b71c0f3eb711558447dbe3f348ef1035', '184.168.224.229', 'Ruby', 1456459004, ''),
('b91ee2464982278dc97f80e1eb27e211', '184.168.224.229', 'Ruby', 1456360728, ''),
('c63b2aa1751a08adecc4bddd545bff1b', '184.168.224.229', 'Ruby', 1455236068, ''),
('c99e85b44708089b2d86b988a710ceca', '184.168.224.230', 'Ruby', 1455757874, ''),
('cc4c301b20878f653c28d0cd04c3455d', '184.168.224.231', 'Ruby', 1455848392, ''),
('ce3036eaedfe3c8f949a0f97f645e82a', '184.168.224.229', 'Ruby', 1456274513, ''),
('d2024a3419c54e36a615ee43b9f60dbc', '184.168.224.230', 'Ruby', 1456622232, ''),
('d2afaeda07ae8f4ecca7517c3adb47e4', '184.168.224.231', 'Ruby', 1456883935, ''),
('d4b27449257a2e7976e2be6ba7cdc9c9', '70.49.25.38', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0', 1455245579, 'a:2:{s:7:"user_id";s:1:"5";s:13:"user_language";s:5:"en-GB";}'),
('ea6f0bb58d0b3d41f15aa049169623cc', '184.168.224.231', 'Ruby', 1456707299, ''),
('f1c0ee37f10fa3b768e8c1a639f302d5', '184.168.224.190', 'Ruby', 1455678111, '');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `class_index` int(11) NOT NULL,
  `class_fees` int(11) NOT NULL,
  `class_section` varchar(20) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=18 ;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `class_name`, `class_index`, `class_fees`, `class_section`) VALUES
(1, 'Nusery 1', 1, 45000, 'English'),
(2, 'Nusery 2', 2, 45000, 'English'),
(3, 'Primary 1', 3, 40000, 'English'),
(4, 'Primary 2', 4, 40000, 'English'),
(5, 'Primary 3', 5, 40000, 'English'),
(6, 'Primary 4', 6, 40000, 'English'),
(7, 'Primary 5', 7, 40000, 'English'),
(8, 'Primary 6', 8, 50000, 'English'),
(9, 'Petite Section', 1, 45000, 'French'),
(10, 'Grande Section', 2, 45000, 'French'),
(11, 'La CIL', 3, 40000, 'French'),
(12, 'Cout Preparatoire', 4, 40000, 'French'),
(13, 'Cout Elementaire 1', 5, 40000, 'French'),
(14, 'Cout Elementaire 2', 6, 40000, 'French'),
(15, 'Cout Moyen 1', 7, 40000, 'French'),
(16, 'Cout Moyen 2', 8, 50000, 'French'),
(17, 'Pre-Nursery', 0, 45000, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `class_teachers`
--

CREATE TABLE IF NOT EXISTS `class_teachers` (
  `class_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  KEY `fk_levels_has_Staff_levels1` (`class_id`),
  KEY `fk_levels_has_Staff_Staff1` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `class_teachers`
--

INSERT INTO `class_teachers` (`class_id`, `staff_id`) VALUES
(8, 10),
(2, 8),
(3, 16),
(4, 19),
(5, 18),
(6, 17),
(7, 21),
(11, 20),
(10, 12),
(9, 14),
(12, 7),
(13, 15),
(14, 11),
(15, 13),
(16, 6),
(17, 9),
(1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE IF NOT EXISTS `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `course_code` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `course_description` text COLLATE latin1_general_ci,
  `class_id` int(11) NOT NULL,
  PRIMARY KEY (`course_id`),
  KEY `fk_Courses_classes1` (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `course_code`, `course_description`, `class_id`) VALUES
(1, 'English', 'ENG', '', 1),
(2, 'French', 'FRE', '', 1),
(3, 'Mathematics', 'MAT', 'Maths', 1),
(5, 'Sports', 'SPT', '', 1),
(7, 'French', 'FRE', '', 2),
(8, 'History', 'HIS', 'hdf', 2),
(10, 'English', 'ENG', 'j', 4),
(11, 'French', 'FRE', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE IF NOT EXISTS `enrollments` (
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `academic_year` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `enrollment_id` int(11) NOT NULL AUTO_INCREMENT,
  `fees_due` int(11) NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  KEY `fk_Students_has_levels_Students1` (`student_id`),
  KEY `fk_Students_has_levels_levels1` (`class_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`student_id`, `class_id`, `academic_year`, `enrollment_id`, `fees_due`) VALUES
(52, 1, '2015/2016', 58, 45000),
(53, 3, '2015/2016', 59, 40000),
(54, 3, '2015/2016', 60, 40000),
(56, 6, '2015/2016', 61, 40000),
(58, 6, '2015/2016', 63, 40000),
(59, 13, '2015/2016', 64, 40000),
(60, 2, '2015/2016', 65, 45000),
(62, 11, '2015/2016', 67, 40000),
(63, 15, '2015/2016', 68, 40000),
(64, 14, '2015/2016', 69, 40000),
(66, 4, '2015/2016', 71, 40000),
(67, 5, '2015/2016', 72, 40000),
(68, 1, '2015/2016', 73, 45000),
(69, 1, '2015/2016', 74, 45000),
(70, 1, '2015/2016', 75, 45000),
(71, 4, '2015/2016', 76, 40000),
(72, 4, '2015/2016', 77, 40000),
(74, 2, '2015/2016', 79, 45000),
(75, 4, '2015/2016', 80, 40000),
(77, 13, '2015/2016', 82, 40000),
(78, 12, '2015/2016', 83, 40000),
(79, 6, '2015/2016', 84, 40000),
(80, 1, '2015/2016', 85, 45000),
(81, 3, '2015/2016', 86, 40000),
(83, 3, '2015/2016', 88, 40000),
(85, 2, '2015/2016', 90, 45000),
(86, 12, '2015/2016', 91, 40000),
(87, 3, '2015/2016', 92, 40000),
(88, 13, '2015/2016', 93, 40000),
(89, 15, '2015/2016', 94, 40000),
(90, 14, '2015/2016', 95, 40000),
(91, 10, '2015/2016', 96, 45000),
(93, 6, '2015/2016', 98, 40000),
(94, 3, '2015/2016', 99, 40000),
(95, 2, '2015/2016', 100, 45000),
(96, 5, '2015/2016', 101, 40000),
(98, 14, '2015/2016', 103, 40000),
(99, 10, '2015/2016', 104, 45000),
(100, 13, '2015/2016', 105, 40000),
(101, 12, '2015/2016', 106, 40000),
(102, 1, '2015/2016', 107, 45000),
(103, 10, '2015/2016', 108, 45000),
(104, 1, '2015/2016', 109, 45000),
(105, 5, '2015/2016', 110, 40000),
(106, 3, '2015/2016', 111, 40000);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment_courses`
--

CREATE TABLE IF NOT EXISTS `enrollment_courses` (
  `Grade` char(1) COLLATE latin1_general_ci DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `enrollment_course_id` int(11) NOT NULL AUTO_INCREMENT,
  `teaching_staff_id` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `enrollment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  PRIMARY KEY (`enrollment_course_id`,`student_id`),
  KEY `fk_Students_has_Courses_Courses1` (`course_id`),
  KEY `fk_Course_Enrollments_Staff1` (`teaching_staff_id`),
  KEY `fk_student_courses_Student_Levels1` (`enrollment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=225 ;

--
-- Dumping data for table `enrollment_courses`
--

INSERT INTO `enrollment_courses` (`Grade`, `course_id`, `enrollment_course_id`, `teaching_staff_id`, `score`, `enrollment_id`, `student_id`) VALUES
(NULL, 1, 181, 9, NULL, 58, 52),
(NULL, 2, 182, 9, NULL, 58, 52),
(NULL, 3, 183, 9, NULL, 58, 52),
(NULL, 5, 184, 9, NULL, 58, 52),
(NULL, 7, 185, 8, NULL, 65, 60),
(NULL, 8, 186, 8, NULL, 65, 60),
(NULL, 10, 187, 19, NULL, 71, 66),
(NULL, 11, 188, 19, NULL, 71, 66),
(NULL, 1, 189, 9, NULL, 73, 68),
(NULL, 2, 190, 9, NULL, 73, 68),
(NULL, 3, 191, 9, NULL, 73, 68),
(NULL, 5, 192, 9, NULL, 73, 68),
(NULL, 1, 193, 9, NULL, 74, 69),
(NULL, 2, 194, 9, NULL, 74, 69),
(NULL, 3, 195, 9, NULL, 74, 69),
(NULL, 5, 196, 9, NULL, 74, 69),
(NULL, 1, 197, 9, NULL, 75, 70),
(NULL, 2, 198, 9, NULL, 75, 70),
(NULL, 3, 199, 9, NULL, 75, 70),
(NULL, 5, 200, 9, NULL, 75, 70),
(NULL, 10, 201, 19, NULL, 76, 71),
(NULL, 11, 202, 19, NULL, 76, 71),
(NULL, 10, 203, 19, NULL, 77, 72),
(NULL, 11, 204, 19, NULL, 77, 72),
(NULL, 7, 205, 8, NULL, 79, 74),
(NULL, 8, 206, 8, NULL, 79, 74),
(NULL, 10, 207, 19, NULL, 80, 75),
(NULL, 11, 208, 19, NULL, 80, 75),
(NULL, 1, 209, 9, NULL, 85, 80),
(NULL, 2, 210, 9, NULL, 85, 80),
(NULL, 3, 211, 9, NULL, 85, 80),
(NULL, 5, 212, 9, NULL, 85, 80),
(NULL, 7, 213, 8, NULL, 90, 85),
(NULL, 8, 214, 8, NULL, 90, 85),
(NULL, 7, 215, 8, NULL, 100, 95),
(NULL, 8, 216, 8, NULL, 100, 95),
(NULL, 1, 217, 9, NULL, 107, 102),
(NULL, 2, 218, 9, NULL, 107, 102),
(NULL, 3, 219, 9, NULL, 107, 102),
(NULL, 5, 220, 9, NULL, 107, 102),
(NULL, 1, 221, 9, NULL, 109, 104),
(NULL, 2, 222, 9, NULL, 109, 104),
(NULL, 3, 223, 9, NULL, 109, 104),
(NULL, 5, 224, 9, NULL, 109, 104);

-- --------------------------------------------------------

--
-- Stand-in structure for view `enrollment_details`
--
CREATE TABLE IF NOT EXISTS `enrollment_details` (
`enrollment_id` int(11)
,`student_id` int(11)
,`class_id` int(11)
,`academic_year` varchar(45)
,`student_name` varchar(45)
,`fees_due` int(11)
,`amount_paid` decimal(32,0)
,`scholarship_amount` double
,`fees_outstanding` double
);
-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `permission_level` int(11) NOT NULL,
  PRIMARY KEY (`permission_id`,`permission_level`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `permission_name`, `permission_level`) VALUES
(21, 'Add, Edit or Delete Enrollments', 2),
(22, 'View Fee Payments', 4),
(23, 'Record Fee Payments', 8),
(24, 'View Scholarships', 16),
(25, 'Award Scholarships', 32),
(26, 'View Classes  and Subjects', 64),
(27, 'Edit Classes and Subjects', 128),
(28, 'View Staff Information', 256),
(29, 'View Enrollments', 1),
(30, 'Edit Staff Info', 512),
(31, 'View Salary Payments', 1024),
(32, 'Record Salary Payments', 2048),
(33, 'Edit User Info', 8192),
(34, 'View Users', 4096),
(35, 'Edit School Info', 32768),
(36, 'View School Info', 16384);

-- --------------------------------------------------------

--
-- Table structure for table `permission_groups`
--

CREATE TABLE IF NOT EXISTS `permission_groups` (
  `group_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `group_permission_value` int(11) NOT NULL,
  `group_description` text COLLATE latin1_general_ci,
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `permission_groups`
--

INSERT INTO `permission_groups` (`group_name`, `group_permission_value`, `group_description`, `group_id`) VALUES
('Head Masters', 20419, 'This group is for the head master. It grants access to student enrollments and all class/subject settings', 1),
('Admin', 65535, 'Administrators. Have system wide access', 2);

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE IF NOT EXISTS `resources` (
  `resource_id` int(11) NOT NULL AUTO_INCREMENT,
  `language` enum('en-GB','fr-FR') COLLATE latin1_general_ci NOT NULL DEFAULT 'en-GB',
  `resource_name` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `resource_value` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`resource_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=348 ;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`resource_id`, `language`, `resource_name`, `resource_value`) VALUES
(1, 'en-GB', 'user_name', 'Username: '),
(2, 'en-GB', 'password', 'Password'),
(3, 'en-GB', 'login', 'Login'),
(4, 'en-GB', 'username_or_password_incorrect', 'Username or Password is incorrect !!!'),
(5, 'en-GB', 'logout', 'Logout'),
(6, 'en-GB', 'students', 'Students'),
(7, 'en-GB', 'subjects', 'Subjects'),
(8, 'en-GB', 'classses', 'Classes'),
(9, 'en-GB', 'staff', 'Staff'),
(10, 'en-GB', 'enrollments', 'Enrollments'),
(11, 'en-GB', 'fee_payments', 'Fee Payments'),
(12, 'en-GB', 'salary_payments', 'Salary Payments'),
(13, 'en-GB', 'users', 'Users'),
(14, 'en-GB', 'school_info', 'School Info'),
(15, 'en-GB', 'new_student', 'New Student'),
(16, 'en-GB', 'view', 'View'),
(17, 'en-GB', 'edit', 'Edit'),
(18, 'en-GB', 'student_number', 'Student Number'),
(19, 'en-GB', 'student_name', 'Student Name'),
(20, 'en-GB', 'date_of_birth', 'Date of Birth'),
(21, 'en-GB', 'gender', 'Gender'),
(22, 'en-GB', 'language', 'Language'),
(23, 'en-GB', 'english', 'English'),
(24, 'en-GB', 'french', 'French'),
(25, 'en-GB', 'picture_optional', 'Picture (Optional)'),
(26, 'en-GB', 'save', 'Save'),
(27, 'en-GB', 'dd_mm_yyyy', '(dd/mm/yyyy)'),
(28, 'en-GB', 'delete', 'Delete'),
(29, 'en-GB', 'yes', 'Yes'),
(30, 'en-GB', 'no', 'No'),
(31, 'en-GB', 'are_you_sure', 'Are you sure?'),
(32, 'en-GB', 'class', 'Class'),
(33, 'en-GB', 'search', 'Search'),
(34, 'en-GB', 'new_subject', 'New Subject'),
(35, 'en-GB', 'subject_code', 'Subject Code'),
(36, 'en-GB', 'subject_name', 'Subject Name'),
(37, 'en-GB', 'subject_description', 'Subject Description'),
(38, 'en-GB', 'classes', 'Classes'),
(39, 'en-GB', 'new_class', 'New Class'),
(40, 'en-GB', 'section', 'Section'),
(41, 'en-GB', 'index', 'Index'),
(42, 'en-GB', 'class_name', 'Class Name'),
(43, 'en-GB', 'fees', 'Fees'),
(44, 'en-GB', 'teacher_optional', 'Teacher Optional'),
(45, 'en-GB', 'teacher', 'Teacher'),
(46, 'en-GB', 'fees_cfa', 'Fees (CFA)'),
(47, 'en-GB', 'new_staff', 'New Staff'),
(48, 'en-GB', 'name', 'Name'),
(49, 'en-GB', 'role', 'Role'),
(50, 'en-GB', 'male', 'Male'),
(51, 'en-GB', 'female', 'Female'),
(52, 'en-GB', 'required_fields', 'Required Fields'),
(53, 'en-GB', 'optional_fields', 'Optional Fields'),
(54, 'en-GB', 'staff_name', 'Staff Name'),
(55, 'en-GB', 'salary', 'Salary'),
(56, 'en-GB', 'qualification', 'Qualification'),
(57, 'en-GB', 'email', 'Email'),
(58, 'en-GB', 'phone_number', 'Phone Number'),
(59, 'en-GB', 'address', 'Address'),
(60, 'en-GB', 'class_enrollments', 'Class Enrollments'),
(61, 'en-GB', 'academic_year', 'Academic Year'),
(62, 'en-GB', 'new_enrollment', 'New Enrollment'),
(63, 'en-GB', 'class_teacher', 'Class Teacher'),
(64, 'en-GB', 'no_students_in_this_class', 'No students in this class and academic year'),
(65, 'en-GB', 'students_in', 'Students in'),
(66, 'en-GB', 'student_course_list', 'Student Course List'),
(67, 'en-GB', 'promote_student', 'Promote Student'),
(68, 'en-GB', 'score', 'Score'),
(69, 'en-GB', 'grade', 'Grade'),
(70, 'en-GB', 'are_you_sure_to_promote', 'Are you sure you want to promote %student to %class in %academic_year?'),
(71, 'en-GB', 'search_for_students_to_enroll', 'Search for Student to Enroll'),
(72, 'en-GB', 'new_payment', 'New Payment'),
(73, 'en-GB', 'payment_date', 'Date Recorded'),
(74, 'en-GB', 'paid_by', 'Paid by'),
(75, 'en-GB', 'amount', 'Amount'),
(76, 'en-GB', 'is_scholarship', 'Is Scholarship'),
(77, 'en-GB', 'amount_due', 'Amount Due'),
(78, 'en-GB', 'amount_paid', 'Amount Paid'),
(79, 'en-GB', 'back', 'Back'),
(80, 'en-GB', 'no_students', 'No Students'),
(81, 'en-GB', 'paid_to', 'Paid To'),
(82, 'en-GB', 'amount_cfa', 'Amount (CFA)'),
(83, 'en-GB', 'purpose_of_payment', 'Purpose of Payment'),
(84, 'en-GB', 'required_fields_validation', '%s is required'),
(85, 'en-GB', 'invalid_fields_validation', '$s is invalid'),
(86, 'en-GB', 'is_numeric_validation', '%s must contain only numbers'),
(87, 'en-GB', 'new_user', 'New User'),
(88, 'en-GB', 'permission_groups', 'Permission Groups'),
(89, 'en-GB', 'full_name', 'Full Name'),
(90, 'en-GB', 'permission', 'Permission'),
(91, 'en-GB', 'is_admin', 'Is Admin'),
(92, 'en-GB', 'group_name', 'Group Name'),
(93, 'en-GB', 'new_permission_group', 'New Permission Group'),
(94, 'en-GB', 'group_description', 'Group Description'),
(95, 'en-GB', 'group_permissions', 'Group Permissions'),
(96, 'fr-FR', 'user_name', 'Nom d''utilisateur'),
(97, 'fr-FR', 'password', 'Mot de passe'),
(98, 'fr-FR', 'login', 'Connexion'),
(99, 'fr-FR', 'username_or_password_incorrect', 'Nom d''utilisateur ou mot de passe n''est pas correcte'),
(100, 'fr-FR', 'logout', 'Deconnexion'),
(101, 'fr-FR', 'students', 'élèves'),
(102, 'fr-FR', 'subjects', 'matières'),
(103, 'fr-FR', 'classses', 'classes'),
(104, 'fr-FR', 'staff', 'personnel'),
(105, 'fr-FR', 'enrollments', 'inscriptions'),
(106, 'fr-FR', 'fee_payments', 'pensions'),
(107, 'fr-FR', 'salary_payments', 'salaires'),
(108, 'fr-FR', 'users', 'utilisateurs'),
(109, 'fr-FR', 'school_info', 'infos sur l''école'),
(110, 'fr-FR', 'new_student', 'nouvel élève'),
(111, 'fr-FR', 'view', 'voir'),
(112, 'fr-FR', 'edit', 'modifier'),
(113, 'fr-FR', 'student_number', 'matricule d''élève'),
(114, 'fr-FR', 'student_name', 'nom d''élève'),
(115, 'fr-FR', 'date_of_birth', 'date de naissance'),
(116, 'fr-FR', 'gender', 'sexe'),
(117, 'fr-FR', 'language', 'Langue'),
(118, 'fr-FR', 'english', 'anglais'),
(119, 'fr-FR', 'french', 'français'),
(120, 'fr-FR', 'picture_optional', 'photo (facultatif)'),
(121, 'fr-FR', 'save', 'enregistrer'),
(122, 'fr-FR', 'dd_mm_yyyy', 'jj/mm/aaaa'),
(123, 'fr-FR', 'delete', 'supprimer'),
(124, 'fr-FR', 'yes', 'Oui'),
(125, 'fr-FR', 'no', 'Non'),
(126, 'fr-FR', 'are_you_sure', 'êtes-vous sûr?'),
(127, 'fr-FR', 'class', 'classe'),
(128, 'fr-FR', 'search', 'recherche'),
(129, 'fr-FR', 'new_subject', 'nouveau matières'),
(130, 'fr-FR', 'subject_code', 'code'),
(131, 'fr-FR', 'subject_name', 'matières'),
(132, 'fr-FR', 'subject_description', 'description'),
(133, 'fr-FR', 'classes', 'classes'),
(134, 'fr-FR', 'new_class', 'nouvelle classe'),
(135, 'fr-FR', 'section', 'Section'),
(136, 'fr-FR', 'index', 'Index'),
(137, 'fr-FR', 'class_name', 'Classe'),
(138, 'fr-FR', 'fees', 'pension'),
(139, 'fr-FR', 'teacher_optional', 'maître (facultatif)'),
(140, 'fr-FR', 'teacher', 'maître'),
(141, 'fr-FR', 'fees_cfa', 'pension (CFA)'),
(142, 'fr-FR', 'new_staff', 'nouveau personnel'),
(143, 'fr-FR', 'name', 'Nom'),
(144, 'fr-FR', 'role', 'rôle'),
(145, 'fr-FR', 'male', 'masculin'),
(146, 'fr-FR', 'female', 'féminin'),
(147, 'fr-FR', 'required_fields', 'obligatoires'),
(148, 'fr-FR', 'optional_fields', 'facultatifs'),
(149, 'fr-FR', 'staff_name', 'nom'),
(150, 'fr-FR', 'salary', 'Salaire'),
(151, 'fr-FR', 'qualification', 'Qualification'),
(152, 'fr-FR', 'email', 'e-mail'),
(153, 'fr-FR', 'phone_number', 'numéro de téléphone'),
(154, 'fr-FR', 'address', 'addresse'),
(155, 'fr-FR', 'class_enrollments', 'inscriptions'),
(156, 'fr-FR', 'academic_year', 'année scolaire'),
(157, 'fr-FR', 'new_enrollment', 'Nouvelle inscription'),
(158, 'fr-FR', 'class_teacher', 'maître du class'),
(159, 'fr-FR', 'no_students_in_this_class', 'pas d''élèves dans cette classe'),
(160, 'fr-FR', 'students_in', 'élèves dans'),
(161, 'fr-FR', 'student_course_list', 'Liste des cours d''élève'),
(162, 'fr-FR', 'promote_student', 'envoyer l''élève a la classe suivante'),
(163, 'fr-FR', 'score', 'Score'),
(164, 'fr-FR', 'grade', 'Mention'),
(165, 'fr-FR', 'are_you_sure_to_promote', 'êtes-vous sûr que vous voulez promouvoir %student à %class pour l''année scolaire $academic_year?'),
(166, 'fr-FR', 'search_for_students_to_enroll', 'chercher des élèves de se inscrire'),
(167, 'fr-FR', 'new_payment', 'nouveau paiement'),
(168, 'fr-FR', 'payment_date', 'date d''enregistrement'),
(169, 'fr-FR', 'paid_by', 'payé par'),
(170, 'fr-FR', 'amount', 'montant'),
(171, 'fr-FR', 'is_scholarship', 'est la bourse'),
(172, 'fr-FR', 'amount_due', 'montant dû'),
(173, 'fr-FR', 'amount_paid', 'le montant payé'),
(174, 'fr-FR', 'back', 'rentrez'),
(175, 'fr-FR', 'no_students', 'aucun élèves '),
(176, 'fr-FR', 'paid_to', 'versée à'),
(177, 'fr-FR', 'amount_cfa', 'montant (CFA)'),
(178, 'fr-FR', 'purpose_of_payment', 'payé pour'),
(179, 'fr-FR', 'required_fields_validation', '%s est nécessaire'),
(180, 'fr-FR', 'invalid_fields_validation', '%s est invalide'),
(181, 'fr-FR', 'is_numeric_validation', '%s doit être numérique'),
(182, 'fr-FR', 'new_user', 'nouvel utilisateur'),
(183, 'fr-FR', 'permission_groups', 'groupes d''autorisations'),
(184, 'fr-FR', 'full_name', 'nom et prénom'),
(185, 'fr-FR', 'permission', 'Permission'),
(186, 'fr-FR', 'is_admin', 'Admin'),
(187, 'fr-FR', 'group_name', 'nom de groupe'),
(188, 'fr-FR', 'new_permission_group', 'nouveau groupe d''autorisation'),
(189, 'fr-FR', 'group_description', 'description du groupe'),
(190, 'fr-FR', 'group_permissions', 'permissions de groupe'),
(223, 'en-GB', 'new_student_created', 'New Student Created'),
(224, 'fr-FR', 'new_student_created', 'Nouvelle élève créé avec succès'),
(225, 'en-GB', 'edit_or_save_the_proposed_student_number', 'Edit or save the proposed Student Number'),
(226, 'fr-FR', 'edit_or_save_the_proposed_student_number', 'Modifier ou enregistrer le matricule d''élève proposé'),
(227, 'en-GB', 'nationality', 'Nationality'),
(228, 'fr-FR', 'nationality', 'Nationalité'),
(229, 'en-GB', 'student', 'Student'),
(230, 'fr-FR', 'student', 'élève'),
(231, 'en-GB', 'enroll_student', 'Enroll Student'),
(232, 'fr-FR', 'enroll_student', 's''inscrire l''élève'),
(233, 'en-GB', 'no_class_in_database', 'No class in database'),
(234, 'fr-FR', 'no_class_in_database', 'aucune classe '),
(235, 'en-GB', 'subject', 'Subject'),
(236, 'fr-FR', 'subject', 'Matière'),
(237, 'en-GB', 'ok', 'OK'),
(238, 'fr-FR', 'ok', 'OK'),
(239, 'fr-FR', 'is_already_in', 'est deja en'),
(240, 'en-GB', 'for', 'for'),
(241, 'en-GB', 'is_already_in', 'is already in'),
(242, 'fr-FR', 'for', 'pour'),
(243, 'en-GB', 'none', 'None'),
(244, 'fr-FR', 'none', 'aucun'),
(245, 'en-GB', 'january', 'January'),
(246, 'en-GB', 'february', 'February'),
(247, 'en-GB', 'march', 'March'),
(248, 'en-GB', 'april', 'April'),
(249, 'en-GB', 'may', 'May'),
(250, 'en-GB', 'june', 'June'),
(251, 'en-GB', 'july', 'July'),
(252, 'en-GB', 'august', 'August'),
(253, 'en-GB', 'september', 'September'),
(254, 'en-GB', 'october', 'October'),
(255, 'en-GB', 'november', 'November'),
(256, 'en-GB', 'december', 'December'),
(257, 'fr-FR', 'january', 'Janvier'),
(258, 'fr-FR', 'february', 'Fevrier'),
(259, 'fr-FR', 'march', 'Mars'),
(260, 'fr-FR', 'april', 'Avril'),
(261, 'fr-FR', 'may', 'Mai'),
(262, 'fr-FR', 'june', 'Juin'),
(263, 'fr-FR', 'july', 'Julliet'),
(264, 'fr-FR', 'august', 'Aout'),
(265, 'fr-FR', 'september', 'Septembre'),
(266, 'fr-FR', 'october', 'Octobre'),
(267, 'fr-FR', 'november', 'Novembre'),
(268, 'fr-FR', 'december', 'Decembre'),
(269, 'en-GB', 'unique_field_validation', '%s must be unique'),
(270, 'fr-FR', 'unique_field_validation', '%s doit etre unique'),
(271, 'en-GB', 'subject_code_and_name_must_be_unique_for', 'Subject code, and Subject Name must be unique for this class'),
(272, 'fr-FR', 'subject_code_and_name_must_be_unique_for', 'code et nom doivent etre unique pour cette classe'),
(273, 'en-GB', 'school_name', 'School Name'),
(274, 'fr-FR', 'school_name', 'Nom d''ecole'),
(275, 'en-GB', 'time_zone', 'Time Zone'),
(276, 'fr-FR', 'time_zone', 'Region de temps'),
(277, 'en-GB', 'keyword', 'Keyword'),
(278, 'fr-FR', 'keyword', 'Mot du recherche'),
(279, 'en-GB', 'student_already_in_class_and_year', 'The student is already in the specified class for the specified academic year'),
(280, 'fr-FR', 'student_already_in_class_and_year', 'L''élève est deja dans la classe pour l''annèe scolaire donné'),
(283, 'en-GB', 'provided_date_invalid', 'Provided date is invalid'),
(284, 'fr-FR', 'provided_date_invalid', 'La date n''est pas correcte'),
(285, 'en-GB', 'no_class_after', 'There is no registered class after '),
(286, 'fr-FR', 'no_class_after', 'pas de classe apres  '),
(287, 'en-GB', 'fees_paid', 'Fees Paid'),
(288, 'fr-FR', 'fees_paid', 'Pension payés'),
(289, 'en-GB', 'status', 'Status'),
(290, 'fr-FR', 'status', 'statut'),
(291, 'fr-FR', 'incomplete', 'incomplet'),
(292, 'fr-FR', 'unpaid', 'impayée'),
(293, 'fr-FR', 'complete', 'complet'),
(294, 'en-GB', 'complete', 'Complete'),
(295, 'en-GB', 'unpaid', 'Unpaid'),
(296, 'en-GB', 'incomplete', 'Incomplete'),
(297, 'fr-FR', 'phone_number', 'numéro de téléphone'),
(298, 'en-GB', 'logo', 'Logo'),
(299, 'fr-FR', 'logo', 'logo'),
(300, 'en-GB', 'recorded_by', 'Recorded By'),
(301, 'fr-FR', 'recorded_by', 'enregistré par'),
(302, 'fr-FR', 'all_students', 'tous les élèves'),
(303, 'en-GB', 'all_students', 'All Students'),
(304, 'fr-FR', 'scholarships', 'les bourses'),
(305, 'en-GB', 'scholarships', 'Scholarships'),
(306, 'fr-FR', 'amount_owed', 'dette'),
(307, 'en-GB', 'amount_owed', 'Amount Owed'),
(308, 'en-GB', 'date_recorded', 'Date Recorded'),
(309, 'fr-FR', 'date_recorded', 'date d''enregistration'),
(310, 'fr-FR', 'scholarship_amount', 'montant de la bourse'),
(311, 'en-GB', 'scholarship_amount', 'Scholarship Amount'),
(312, 'fr-FR', 'enrollment_for', 'inscription pour'),
(313, 'en-GB', 'enrollment_for', 'Enrollment for'),
(314, 'fr-FR', 'award_scholarship', 'donner une bourse'),
(315, 'en-GB', 'award_scholarship', 'Award Scholarship'),
(316, 'en-GB', 'view_scholarship', 'View Scholarship'),
(317, 'fr-FR', 'view_scholarship', 'voyez la bourse'),
(318, 'fr-FR', 'pay_fees', 'payer les frais'),
(319, 'en-GB', 'pay_fees', 'Pay Fees'),
(320, 'fr-FR', 'home', 'accueil'),
(321, 'en-GB', 'home', 'Home'),
(322, 'en-GB', 'enrollment_stats', 'Enrollment Statistics'),
(323, 'fr-FR', 'enrollment_stats', 'Statistiques inscription'),
(324, 'fr-FR', 'enrollment_count', 'Nombre d''inscriptions'),
(325, 'en-GB', 'enrollment_count', 'Enrollment Count'),
(326, 'en-GB', 'completed_fee_payments', 'Completed Fee Payments'),
(327, 'fr-FR', 'completed_fee_payments', 'pensions complets'),
(328, 'en-GB', 'incomplete_payments', 'Incomplete Payments'),
(329, 'fr-FR', 'incomplete_payments', 'pensions incomplets'),
(330, 'en-GB', 'unpaid_enrollments', 'Unpaid Enrollments'),
(331, 'fr-FR', 'unpaid_enrollments', 'inscriptions impayées'),
(332, 'en-GB', 'Unavailable', 'Unavailable'),
(333, 'fr-FR', 'Unavailable', 'indisponible'),
(334, 'en-GB', 'Unavailable', 'Unavailable'),
(335, 'fr-FR', 'Unavailable', 'indisponible'),
(336, 'en-GB', 'reason', 'Reason'),
(337, 'fr-FR', 'reason', 'raison'),
(338, 'en-GB', 'reason', 'Reason'),
(339, 'fr-FR', 'reason', 'raison'),
(340, 'fr-FR', 'total_amount_expected', 'Montant total prévu'),
(341, 'en-GB', 'total_amount_expected', 'Total Amount expected'),
(342, 'en-GB', 'total_amount_paid', 'Total Amount Paid'),
(343, 'fr-FR', 'total_amount_paid', 'Montant total payé'),
(344, 'en-GB', 'total_scholarship_awarded', 'Total Scholarship Awarded'),
(345, 'fr-FR', 'total_scholarship_awarded', 'bourse total'),
(346, 'en-GB', 'total_amount_pending', 'Total Pending'),
(347, 'fr-FR', 'total_amount_pending', 'montant restant');

-- --------------------------------------------------------

--
-- Table structure for table `salary_payments`
--

CREATE TABLE IF NOT EXISTS `salary_payments` (
  `staff_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `purpose` text COLLATE latin1_general_ci,
  `academic_year` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `date_recorded` datetime DEFAULT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_SalaryPayments_Staff1` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `scholarships`
--

CREATE TABLE IF NOT EXISTS `scholarships` (
  `scholarship_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `description` text COLLATE latin1_general_ci,
  `enrollment_id` int(11) DEFAULT NULL,
  `date_recorded` datetime DEFAULT NULL,
  `recorded_by_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`scholarship_id`),
  KEY `scholarships_enrollments_FK` (`enrollment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `scholarships`
--

INSERT INTO `scholarships` (`scholarship_id`, `amount`, `description`, `enrollment_id`, `date_recorded`, `recorded_by_user_id`) VALUES
(6, '5000', '3rd pupil registered from the same familly', 93, '2015-10-10 08:01:08', 3),
(7, '3000', '', 94, '2015-10-10 08:04:14', 3),
(8, '5000', 'Teacher''s first registered child', 107, '2015-10-10 08:39:11', 3);

-- --------------------------------------------------------

--
-- Table structure for table `school_info`
--

CREATE TABLE IF NOT EXISTS `school_info` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_number` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `address` text COLLATE latin1_general_ci,
  `logo` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `time_zone` tinyint(5) DEFAULT NULL,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `school_info`
--

INSERT INTO `school_info` (`school_id`, `school_name`, `email`, `phone_number`, `address`, `logo`, `time_zone`) VALUES
(1, 'CHARIS BNPS', '', '', 'Douala, Cameroon', 'charis.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_qualification` text COLLATE latin1_general_ci,
  `title` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `salary` int(11) NOT NULL,
  `staff_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_number` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `date_of_birth` datetime DEFAULT NULL,
  `address` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `gender` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `staff_role` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=22 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_qualification`, `title`, `salary`, `staff_name`, `email`, `phone_number`, `date_of_birth`, `address`, `gender`, `staff_role`) VALUES
(5, 'Bsc', NULL, 100000, 'CHIME FRANCINE YASMINE', 'admin.charisbnpsa@gmail.com', '652135193', NULL, '', 'Female', 'SECRETARY / BURSAR'),
(6, '', NULL, 100000, 'PHILLIPINE NAYANG', 'headmaster.charibnps@gmail.com', '675963581', NULL, '', 'Female', 'HEADMISTRESS'),
(7, '', NULL, 40000, 'Pelagie Ebong', '', '', NULL, '', 'Female', 'Teacher CP'),
(8, '', NULL, 35000, 'Christine Djimo', '', '677050282', NULL, '', 'Female', 'Teacher - Nursery 2'),
(9, '', NULL, 35000, 'Rose Ebangha', '', '675194231', NULL, '', 'Female', 'Teacher - Nursery 1'),
(10, '', NULL, 50000, 'Federick Adi', '', '675808139', NULL, '', 'Male', 'Teacher - Class 6'),
(11, '', NULL, 35000, 'Mirene Fanyep', '', '6796410019', NULL, '', 'Female', 'Teacher - CE2'),
(12, '', NULL, 40000, 'Takem Berthe', '', '675905009', NULL, 'NDOBO/BEPELE', 'Female', 'Teacher - MGS'),
(13, '', NULL, 45000, 'Brigitte Tchamtieu', '', '670124312', NULL, 'NDOBO/BEPELE', 'Female', 'Teacher - CM1 '),
(14, '', NULL, 35000, 'Sylvianne Tanko', '', '', NULL, '', 'Female', 'Teacher - MPS'),
(15, '', NULL, 35000, 'Peter Guibolo', '', '', NULL, '', 'Male', 'Teacher - CE1'),
(16, '', NULL, 45000, 'Evelyn Ndawa', '', '', NULL, '', 'Female', 'Teacher - Class 1'),
(17, '', NULL, 37000, 'Emilia Ngalle', '', '670175094', NULL, '', 'Female', 'Teacher - Class 4'),
(18, '', NULL, 35000, 'Eveline Nubia', '', '', NULL, '', 'Female', 'Teacher - Class 3'),
(19, '', NULL, 40000, 'Vivian Domi', '', '675434852', NULL, '', 'Female', 'Teacher - Class 2'),
(20, '', NULL, 45000, 'Alliance F Fomekong', '', '678938172', NULL, '', 'Male', 'Teacher - SIL'),
(21, '', NULL, 40000, 'John Etah', '', '678072970', NULL, '', 'Male', 'Teacher - Class 5');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female') COLLATE latin1_general_ci NOT NULL,
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `picture` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `nationality` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `language` enum('English','French') COLLATE latin1_general_ci NOT NULL,
  `student_number` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=108 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`date_of_birth`, `gender`, `student_id`, `student_name`, `picture`, `nationality`, `language`, `student_number`, `date_created`) VALUES
(NULL, 'male', 16, 'Tchoundi Mimedjeu Van Vicker', NULL, '0', 'English', 'C0001', '2015-09-30 07:43:45'),
('1970-01-01', 'male', 17, 'Tchoundi Mimedjeu Van Vicker', NULL, 'Cameroonian', 'English', 'C0001', '2015-09-30 08:54:18'),
('2013-02-06', 'male', 18, 'Ayuk Youri Vario Esong', NULL, 'Cameroonian', 'English', 'C0002', '2015-09-30 09:27:19'),
('2013-02-06', 'male', 19, 'Ayuk Youri Vario Esong', NULL, 'Cameroonian', 'English', 'C00012016', '2015-09-30 09:30:20'),
('2013-02-06', 'male', 20, 'Ayuk Youri Vario Esong', NULL, 'Cameroonian', 'English', 'C00028', '2015-09-30 09:30:21'),
('2013-01-12', 'male', 21, ' Tadzong Adriano Lavano', NULL, 'Cameroonian', 'English', 'C0039', '2015-09-30 09:33:20'),
('1970-01-01', 'male', 22, 'Tatchinda Brayan', NULL, 'Cameroonian', 'English', 'C0009', '2015-09-30 09:37:51'),
('1970-01-01', 'female', 23, 'Njock victory Ebob', NULL, 'Cameroonian', 'English', 'C0016', '2015-09-30 09:39:07'),
('1970-01-01', 'female', 24, 'Njock Victory Enene', NULL, 'Cameroonian', 'English', 'C0017', '2015-09-30 09:40:33'),
('1970-01-01', 'male', 25, 'Mbah Gennueline Enyoh', NULL, 'Cameroonian', 'English', 'C0018', '2015-09-30 10:08:00'),
('1970-01-01', 'female', 26, 'Frambo Maria-Ciracia Bessem', NULL, 'Cameroonian', 'English', 'C0032', '2015-09-30 10:18:45'),
('1970-01-01', 'male', 27, 'Betchem De-Light Tabi Orock', NULL, 'Cameroonian', 'English', 'C0051', '2015-09-30 10:22:02'),
('1970-01-01', 'male', 28, 'Peshago Moustafa Fung', NULL, 'Cameroonian', 'English', 'C0054', '2015-09-30 10:23:28'),
('1970-01-01', 'male', 29, 'Kwonche Wilfred Miguel', NULL, 'Cameroonian', 'English', 'C0055', '2015-09-30 10:25:55'),
('1970-01-01', 'male', 30, 'Kenfack Istael Telor', NULL, 'Cameroonian', 'English', 'C0065', '2015-09-30 10:28:05'),
('1970-01-01', 'male', 31, 'Ndungwe Javis', NULL, 'Cameroonian', 'English', 'C0117', '2015-09-30 10:29:09'),
('1970-01-01', 'female', 32, 'Aba Vanessa ', NULL, 'Cameroonian', 'English', 'C0140', '2015-09-30 10:30:20'),
('1970-01-01', 'male', 33, 'Kanjoh Ransun Asunyu', NULL, 'Cameroonian', 'English', 'C0143', '2015-09-30 10:32:58'),
('1970-01-01', 'male', 34, 'Yemene sahan Nathan', NULL, 'Cameroonian', 'English', 'C0160', '2015-09-30 10:39:00'),
('1970-01-01', 'male', 35, 'Michael Ofon', NULL, 'Cameroonian', 'English', 'C0177', '2015-09-30 10:40:03'),
('1970-01-01', 'female', 36, 'Nkanjoh Kwassegui Vanessa', NULL, 'Cameroonian', 'English', 'C0178', '2015-09-30 10:41:56'),
('1970-01-01', 'male', 37, 'Fuh Emmanuela Bih', NULL, 'Cameroonian', 'English', 'C0182', '2015-09-30 10:42:54'),
('1970-01-01', 'male', 38, 'Bezeng Nelvin Ofon', NULL, 'Cameroonian', 'English', 'C0184', '2015-09-30 10:43:53'),
('1970-01-01', 'male', 39, 'Ateh Samuel Ntchitu', NULL, 'Cameroonian', 'English', 'C0218', '2015-09-30 11:07:09'),
('1970-01-01', 'male', 40, 'Ofon Prosper', NULL, 'Cameroonian', 'English', 'C0241', '2015-09-30 11:08:05'),
('2012-04-01', 'male', 41, 'Tague Ngouagnia Brayane', NULL, 'Cameroonian', 'English', 'C00022016', '2015-09-30 11:10:52'),
('1970-01-01', 'male', 42, 'Nounezi Messippo Louisant', NULL, 'Cameroonian', 'English', 'C0265', '2015-09-30 11:12:19'),
('1970-01-01', 'female', 43, 'Manka''a Helena Peace', NULL, 'Cameroonian', 'English', 'C0267', '2015-09-30 11:13:31'),
('1970-01-01', 'male', 44, 'Nquimfor Bemyni Kavine', NULL, 'Cameroonian', 'English', 'C0271', '2015-09-30 11:14:32'),
('1970-01-01', 'male', 45, 'Daba Christina', NULL, 'Cameroonian', 'English', 'C00032016', '2015-09-30 11:15:11'),
(NULL, 'male', 46, 'Daba Christina', NULL, '0', 'English', 'C00042016', '2015-09-30 11:15:21'),
('1970-01-01', 'female', 47, 'Daba Christina', NULL, 'Cameroonian', 'English', 'C0291', '2015-09-30 11:15:21'),
('1970-01-01', 'male', 48, 'Tague Foning Angel', NULL, 'Cameroonian', 'English', 'C0292', '2015-09-30 11:16:18'),
('1970-01-01', 'female', 49, 'Zoulayatou Yisah', NULL, 'Cameroonian', 'English', 'C00052016', '2015-09-30 11:38:25'),
('2010-05-15', 'female', 50, 'Zoulayatou Yisah', NULL, 'Cameroonian', 'English', 'C0023', '2015-09-30 11:38:53'),
(NULL, 'male', 52, 'Tchounda M. Van Vicker', NULL, 'Cameroonian', 'English', 'C00062016', '2015-10-05 09:36:50'),
(NULL, 'female', 53, 'Yusifa Mairayamu', NULL, 'Cameroonian', 'English', 'C00072016', '2015-10-05 09:39:05'),
(NULL, 'male', 54, 'Tayong Prosper Agyingi', NULL, 'Cameroonian', 'English', 'C00082016', '2015-10-05 09:40:52'),
(NULL, 'male', 55, 'Tayong prease Edong', NULL, 'Cameroonian', 'English', 'C00092016', '2015-10-05 09:42:25'),
(NULL, 'female', 56, 'Tayong prease Edong', NULL, 'Cameroonian', 'English', 'C00102016', '2015-10-05 09:42:45'),
(NULL, 'female', 57, 'Kenne Lucresse Fabiola', NULL, 'Cameroonian', 'English', 'C00112016', '2015-10-05 09:44:33'),
(NULL, 'male', 58, 'Ndundwe Japhet Foto', NULL, 'Cameroonian', 'English', 'C00122016', '2015-10-06 06:15:00'),
(NULL, 'female', 59, 'Mafokouan Danoucia', NULL, 'Cameroonian', 'English', 'C00132016', '2015-10-08 08:56:33'),
(NULL, 'male', 60, 'Tatchinda Alan', NULL, 'Cameroonian', 'English', 'C00142016', '2015-10-08 08:57:57'),
(NULL, 'male', 61, 'Tatchinda Brayan', NULL, 'Cameroonian', 'English', 'C00152016', '2015-10-08 08:59:05'),
(NULL, 'male', 62, 'Tatchinda Prince', NULL, 'Cameroonian', 'English', 'C00162016', '2015-10-08 09:00:30'),
(NULL, 'female', 63, 'Tatchinda Vasilia', NULL, 'Cameroonian', 'French', 'C00172016', '2015-10-08 11:43:32'),
(NULL, 'female', 64, 'Tatchinda Fortune', NULL, 'Cameroonian', 'English', 'C00182016', '2015-10-08 11:44:42'),
(NULL, 'female', 65, 'Sakwe Sharon Mbone', NULL, 'Cameroonian', 'English', 'C00192016', '2015-10-08 11:48:28'),
(NULL, 'female', 66, 'Zenatou A. Tijani', NULL, 'Cameroonian', 'English', 'C00202016', '2015-10-08 12:20:49'),
(NULL, 'male', 67, 'Kadidatou Tijani', NULL, 'Cameroonian', 'English', 'C00212016', '2015-10-08 12:49:01'),
(NULL, 'female', 68, 'Njock Victory Ebob', NULL, 'Cameroonian', 'English', 'C00222016', '2015-10-08 12:50:23'),
(NULL, 'female', 69, 'Njock Victoire Enene', NULL, 'Cameroonian', 'English', 'C00232016', '2015-10-08 12:51:29'),
(NULL, 'female', 70, 'Mbah Gennueline Enyoh', NULL, 'Cameroonian', 'English', 'C00242016', '2015-10-08 13:10:42'),
(NULL, 'male', 71, 'Mbah Success Akeh', NULL, 'Cameroonian', 'English', 'C00252016', '2015-10-08 13:41:57'),
(NULL, 'male', 72, 'Tita Leovis', NULL, 'Cameroonian', 'English', 'C00262016', '2015-10-08 13:53:41'),
(NULL, 'female', 73, 'Sabi Joyceline', NULL, 'Cameroonian', 'English', 'C00272016', '2015-10-08 13:55:16'),
(NULL, 'male', 74, 'Pozoko Majo Christella', NULL, 'Cameroonian', 'English', 'C00282016', '2015-10-08 14:00:11'),
(NULL, 'female', 75, 'Zouleyatou Yisah', NULL, 'Cameroonian', 'English', 'C00292016', '2015-10-08 14:40:14'),
(NULL, 'female', 76, 'Ayoumen Marbel', NULL, 'Cameroonian', 'English', 'C00302016', '2015-10-08 14:42:15'),
(NULL, 'female', 77, 'segning Sagesse', NULL, 'Cameroonian', 'English', 'C00312016', '2015-10-08 14:44:10'),
(NULL, 'male', 78, 'Tiomena Delmace', NULL, 'Cameroonian', 'English', 'C00322016', '2015-10-08 14:46:35'),
(NULL, 'male', 79, 'Kammongo Ayuk Lysiane Astrid', NULL, 'Cameroonian', 'English', 'C00332016', '2015-10-08 14:48:49'),
(NULL, 'male', 80, 'Ayuk Youri Vario Esong', NULL, 'Cameroonian', 'English', 'C00342016', '2015-10-08 14:50:26'),
(NULL, 'male', 81, 'Zenabo Abdul', NULL, 'Cameroonian', 'English', 'C00352016', '2015-10-08 14:52:51'),
(NULL, 'female', 82, 'Fadimatou Abdul', NULL, 'Cameroonian', 'English', 'C00362016', '2015-10-08 14:54:12'),
(NULL, 'male', 83, 'Frambo Maurice- Christian Agbor', NULL, 'Cameroonian', 'English', 'C00372016', '2015-10-08 14:55:56'),
(NULL, 'female', 84, 'Frambo Maria-Gracia Bessem', NULL, 'Cameroonian', 'English', 'C00382016', '2015-10-09 11:49:57'),
(NULL, 'female', 85, 'Pozoko Majo Christella', NULL, 'Cameroonian', 'English', 'C00392016', '2015-10-09 14:38:08'),
(NULL, 'female', 86, 'Kuete Ange Merveille', NULL, 'Cameroonian', 'English', 'C00402016', '2015-10-10 06:56:28'),
(NULL, 'male', 87, 'Wenengo Yepdio Francois Onesime', NULL, 'Cameroonian', 'English', 'C00412016', '2015-10-10 06:57:55'),
(NULL, 'male', 88, 'Songoua Gouanyo Horelle', NULL, '0', 'French', 'C00422016', '2015-10-10 06:59:56'),
(NULL, 'male', 89, 'Donfack Nzamgue Michael Yoram', NULL, 'Cameroonian', 'French', 'C00432016', '2015-10-10 07:03:48'),
(NULL, 'female', 90, 'Tiwa Foning  Murielle ', NULL, 'Cameroonian', 'French', 'C00442016', '2015-10-10 07:08:36'),
(NULL, 'female', 91, 'Belinguie Foning Indira', NULL, 'Cameroonian', 'French', 'C00452016', '2015-10-10 07:13:16'),
(NULL, 'male', 92, 'Tadzong Moulogipo Adriano Lavano', NULL, 'Cameroonian', 'English', 'C00462016', '2015-10-10 07:14:45'),
(NULL, 'female', 93, 'Jipap Nolak Marcelle Paola', NULL, '0', 'English', 'C00472016', '2015-10-10 07:16:07'),
(NULL, 'female', 94, 'Jipap Banken Andrena Eveline', NULL, 'Cameroonian', 'English', 'C00482016', '2015-10-10 07:20:35'),
(NULL, 'male', 95, 'Sale Issa Phaisale', NULL, '0', 'English', 'C00492016', '2015-10-10 07:22:01'),
(NULL, 'female', 96, 'Sale Maria Gambo', NULL, 'Cameroonian', 'English', 'C00502016', '2015-10-10 07:28:35'),
(NULL, 'female', 97, 'Sale Adama Ousena', NULL, 'Cameroonian', 'English', 'C00512016', '2015-10-10 07:29:38'),
(NULL, 'female', 98, 'Endolle Leonie', NULL, 'Cameroonian', 'French', 'C00522016', '2015-10-10 07:30:47'),
(NULL, 'male', 99, 'Tidou Roger', NULL, 'Cameroonian', 'French', 'C00532016', '2015-10-10 07:32:13'),
(NULL, 'female', 100, 'Ngoba Min Morelle', NULL, 'Cameroonian', 'French', 'C00542016', '2015-10-10 07:34:30'),
(NULL, 'female', 101, 'Tcheumaleu Kamga Rene Vigelle', NULL, 'Cameroonian', 'French', 'C00552016', '2015-10-10 07:35:57'),
(NULL, 'male', 102, 'Etinge Nathan Wellensky Mboge', NULL, 'Cameroonian', 'English', 'C00562016', '2015-10-10 07:38:34'),
(NULL, 'female', 103, 'Leutchom Dehele Anisinne Charole', NULL, 'Cameroonian', 'French', 'C00572016', '2015-10-10 07:41:50'),
(NULL, 'male', 104, 'Bechem De-light Tabi Orock ', NULL, 'Cameroonian', 'English', 'C00582016', '2015-10-10 07:45:03'),
(NULL, 'male', 105, 'Issatou Youssoufa', NULL, 'Cameroonian', 'English', 'C00592016', '2015-10-10 07:55:43'),
(NULL, 'male', 106, 'Tifuh Paticons', NULL, 'Cameroonian', 'English', 'C00602016', '2015-10-10 07:57:29'),
(NULL, 'male', 107, 'Tifuh Paticons', NULL, 'Cameroonian', 'English', 'C00612016', '2015-10-10 08:01:38');

-- --------------------------------------------------------

--
-- Table structure for table `student_fee_payments`
--

CREATE TABLE IF NOT EXISTS `student_fee_payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount_paid` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payer` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `enrollment_id` int(11) NOT NULL,
  `recorded_by_user_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_student_fee_payments_Student_Levels1` (`enrollment_id`),
  KEY `fk_student_fee_payments_users1` (`recorded_by_user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=80 ;

--
-- Dumping data for table `student_fee_payments`
--

INSERT INTO `student_fee_payments` (`payment_id`, `amount_paid`, `payment_date`, `payer`, `enrollment_id`, `recorded_by_user_id`) VALUES
(27, 20000, '2015-10-05 10:37:21', '', 58, 3),
(28, 20000, '2015-10-05 10:39:40', '', 59, 3),
(29, 20000, '2015-10-05 10:41:08', '', 60, 3),
(30, 20000, '2015-10-05 10:43:09', '', 61, 3),
(32, 15000, '2015-10-08 09:57:05', '', 64, 3),
(33, 15000, '2015-10-08 09:58:13', '', 65, 3),
(35, 15000, '2015-10-08 10:00:49', '', 67, 3),
(36, 15000, '2015-10-08 12:43:50', '', 68, 3),
(37, 15000, '2015-10-08 12:45:01', '', 69, 3),
(39, 20000, '2015-10-08 13:21:06', '', 71, 3),
(40, 20000, '2015-10-08 13:49:23', '', 72, 3),
(41, 45000, '2015-10-08 13:50:37', '', 73, 3),
(42, 45000, '2015-10-08 13:51:59', '', 74, 3),
(43, 15000, '2015-10-08 14:11:04', '', 75, 3),
(44, 15000, '2015-10-08 14:42:16', '', 76, 3),
(45, 15000, '2015-10-08 14:54:19', '', 77, 3),
(47, 15000, '2015-10-08 15:00:45', '', 79, 3),
(48, 15000, '2015-10-08 15:40:40', '', 80, 3),
(50, 20000, '2015-10-08 15:44:28', '', 82, 3),
(51, 20000, '2015-10-08 15:46:51', '', 83, 3),
(52, 40000, '2015-10-08 15:49:06', '', 84, 3),
(53, 45000, '2015-10-08 15:50:41', '', 85, 3),
(54, 15000, '2015-10-08 15:53:09', '', 86, 3),
(56, 15000, '2015-10-08 15:56:13', '', 88, 3),
(58, 15000, '2015-10-09 15:38:27', '', 90, 3),
(59, 40000, '2015-10-10 07:56:45', '', 91, 3),
(60, 15000, '2015-10-10 07:58:09', '', 92, 3),
(61, 20000, '2015-10-10 08:00:10', '', 93, 3),
(62, 12000, '2015-10-10 08:04:04', '', 94, 3),
(63, 40000, '2015-10-10 08:08:59', '', 95, 3),
(64, 45000, '2015-10-10 08:13:35', '', 96, 3),
(66, 15000, '2015-10-10 08:16:30', '', 98, 3),
(67, 15000, '2015-10-10 08:21:06', '', 99, 3),
(68, 20000, '2015-10-10 08:27:52', '', 100, 3),
(69, 15000, '2015-10-10 08:28:49', '', 101, 3),
(71, 20000, '2015-10-10 08:31:10', '', 103, 3),
(72, 20000, '2015-10-10 08:33:14', '', 104, 3),
(73, 20000, '2015-10-10 08:35:00', '', 105, 3),
(74, 15000, '2015-10-10 08:36:17', '', 106, 3),
(75, 15000, '2015-10-10 08:39:31', '', 107, 3),
(76, 15000, '2015-10-10 08:42:12', '', 108, 3),
(77, 30000, '2015-10-10 08:45:31', '', 109, 3),
(78, 20000, '2015-10-10 08:56:04', '', 110, 3),
(79, 30000, '2015-10-10 08:57:54', '', 111, 3);

-- --------------------------------------------------------

--
-- Table structure for table `student_guardians`
--

CREATE TABLE IF NOT EXISTS `student_guardians` (
  `guardian_name` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `student_guardian_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_number` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `date_of_birth` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`student_guardian_id`),
  KEY `fk_persons_has_Students_Students1` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(45) COLLATE latin1_general_ci NOT NULL,
  `full_name` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `phone_number` varchar(45) COLLATE latin1_general_ci DEFAULT NULL,
  `permission_level` int(11) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(10) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `permission_level` (`permission_level`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `email`, `phone_number`, `permission_level`, `is_admin`, `language`) VALUES
(1, 'titus', 'Jesus123', 'Yusinyu Titus Nsami', 'titus@suresoft.cm', '679684428', 65535, 1, 'en-GB'),
(3, 'chime', 'yasminecharis', 'Chime Francine Yasmine', '', '', 65535, 1, 'en-GB'),
(5, 'Godlove', '2015godlove', 'Godlove Ngwa', '', '', 65535, 0, 'en-GB'),
(6, 'headmaster', 'charisheadmaster', 'Head Master', '', '', 20419, 0, 'en-GB');

-- --------------------------------------------------------

--
-- Structure for view `enrollment_details`
--
DROP TABLE IF EXISTS `enrollment_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`admincharisbnps`@`localhost` SQL SECURITY DEFINER VIEW `enrollment_details` AS select `e`.`enrollment_id` AS `enrollment_id`,`e`.`student_id` AS `student_id`,`e`.`class_id` AS `class_id`,`e`.`academic_year` AS `academic_year`,`s`.`student_name` AS `student_name`,`e`.`fees_due` AS `fees_due`,sum(coalesce(`st`.`amount_paid`,0)) AS `amount_paid`,sum(coalesce(`sc`.`amount`,0)) AS `scholarship_amount`,((`e`.`fees_due` - sum(coalesce(`st`.`amount_paid`,0))) - sum(coalesce(`sc`.`amount`,0))) AS `fees_outstanding` from (((`enrollments` `e` left join `student_fee_payments` `st` on((`e`.`enrollment_id` = `st`.`enrollment_id`))) left join `scholarships` `sc` on((`e`.`enrollment_id` = `sc`.`enrollment_id`))) left join `students` `s` on((`e`.`student_id` = `s`.`student_id`))) group by `e`.`enrollment_id`,`e`.`student_id`,`e`.`class_id`,`e`.`academic_year`,`s`.`student_name`,`e`.`fees_due`;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class_teachers`
--
ALTER TABLE `class_teachers`
  ADD CONSTRAINT `fk_levels_has_Staff_levels1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_levels_has_Staff_Staff1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_Courses_classes1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_Students_has_levels_levels1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Students_has_levels_Students1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `enrollment_courses`
--
ALTER TABLE `enrollment_courses`
  ADD CONSTRAINT `fk_Course_Enrollments_Staff1` FOREIGN KEY (`teaching_staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Students_has_Courses_Courses1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_student_courses_Student_Levels1` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`enrollment_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `salary_payments`
--
ALTER TABLE `salary_payments`
  ADD CONSTRAINT `fk_SalaryPayments_Staff1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `scholarships`
--
ALTER TABLE `scholarships`
  ADD CONSTRAINT `scholarships_enrollments_FK` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`enrollment_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_fee_payments`
--
ALTER TABLE `student_fee_payments`
  ADD CONSTRAINT `fk_student_fee_payments_Student_Levels1` FOREIGN KEY (`enrollment_id`) REFERENCES `enrollments` (`enrollment_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_student_fee_payments_users1` FOREIGN KEY (`recorded_by_user_id`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `student_guardians`
--
ALTER TABLE `student_guardians`
  ADD CONSTRAINT `fk_persons_has_Students_Students1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
