<?php 
	header("location: ../../../");
?>