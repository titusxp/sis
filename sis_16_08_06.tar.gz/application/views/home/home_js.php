<script type="text/javascript">

(function(){
angular.module('sis', [])
.controller('financeSummaryController', function($scope, $http)
    {
        $scope.showWaitForm = true;
        $scope.selectedYear = '<?php echo get_current_academic_year(); ?>';
        $scope.siteURL = '<?php echo site_url()?>' + '/';
        
        var url = $scope.siteURL + 'home/get_all_finance_summaries';
        
        $http.get(url).success(function(result)
        {
            $scope.showWaitForm = false;
            $scope.summaries = result;
            //$scope.calculateTotals();
        })
        .error(function (data, status, headers, config) 
        {
            $scope.showWaitForm = false;
        });
        
         $scope.calculateTotals = function()
         {
//            $scope.totalIncome = 0;
//            $scope.totalExpense = 0;
//                        
//            alert(angular.toJson($scope.summaries[0]));
//            
//            for(var i = 0; i < $scope.summaries.length; i++)
//            {
//                if($scope.result[i].is_expense > 0)
//                    $scope.totalExpense += $scope.result[i].amount;
//                else
//                    $scope.totalIncome += $scope.result[i].amount;
//            }
         }
})
})();
    
</script>