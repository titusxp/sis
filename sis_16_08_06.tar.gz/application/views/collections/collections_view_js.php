<script type="text/javascript">

(function(){
angular.module('sis', [])
.controller('SearchFeesController', function($scope, $http)
    {   
        $scope.selectedClass = '0';
        $scope.selectedTypeId = '0';
        $scope.selectedType = {};
        $scope.siteURL = '<?php echo site_url() ?>' + '/';
        $scope.selectedYear = '<?php echo get_current_academic_year(); ?>';
        $scope.showWaitForm = true;       
         
        $scope.allowOnlyNumbers = function()
        {
            if(isNaN($scope.newFee))
            {
                $scope.newFee = $scope.newFee.slice(0, -1);
            }
        }
        
        $scope.currentUser = [];
        $http.get($scope.siteURL + 'users/json_get_current_user').success(function(result)
        {
            $scope.currentUser = result;
        });
        
        $scope.allClasses = [];
        $http.get($scope.siteURL + 'global_json_repo/get_all_classes').success(function(result)
        {
            $scope.allClasses = result;
            $scope.selectedClass = result[0].class_id;
            $scope.getCollections();
        });
        
        $scope.allIncomeTypes = [];
        $http.get($scope.siteURL + 'collection_types/json_get_non_system_types/0').success(function(result)
        {
            $scope.allIncomeTypes = result;
            $scope.selectedTypeId = result[0].type_id;
            $scope.getCollections();
        });
        
        
        $scope.allExpenseTypes = [];
        $http.get($scope.siteURL + 'collection_types/json_get_non_system_types/1').success(function(result)
        {
            $scope.allExpenseTypes = result;
            if($scope.selectedTypeId === 0)
            {
                $scope.selectedTypeId = result[0].type_id;
                $scope.getCollections();
            }
        });
        
                
        $scope.allAcademicYears = [];
        $http.get($scope.siteURL + 'global_json_repo/get_all_academic_years').success(function(result)
        {
            $scope.allAcademicYears = result;
            $scope.getCollections();
        });
        
        $scope.collectionTypeChanged = function()
        {
            for(var i = 0; i < $scope.allIncomeTypes.length; i++)
            {
                if($scope.allIncomeTypes[i].type_id === $scope.selectedTypeId)
                {
                    $scope.selectedType = $scope.allIncomeTypes[i];
                    $scope.getCollections();
                    return;
                }
            }
            
            for(var i = 0; i < $scope.allExpenseTypes.length; i++)
            {
                if($scope.allExpenseTypes[i].type_id === $scope.selectedTypeId)
                {
                    $scope.selectedType = $scope.allExpenseTypes[i];
                    $scope.getCollections();
                    return;
                }
            }
        }
                
        
        $scope.getCollections = function()
        {
            $scope.showWaitForm = true;
            $scope.collections = [];
            
            if($scope.selectedClass > 0 && $scope.selectedTypeId > 0 && $scope.selectedYear)
            {
                var url = $scope.siteURL + 'collections/json_get_collections';
                url += '/' + $scope.selectedClass + '/' + $scope.selectedYear.replace("/", "and");
                url += '/' + $scope.selectedTypeId;
                $http.get(url).success(function(result)
                {
                    $scope.showWaitForm = false;
                    $scope.collections =  result;

                    $scope.collectionsEmpty = result.length === 0;

                }).error(function (data, status, headers, config) 
                {
                    $scope.showWaitForm = false;
                });
            }
        };
        
        $scope.showCollection = function(col)
        {
            $scope.showWaitForm = true;
            $scope.currentCollection = [];
            if(col.collection_id > 0)
            {
                var collectionUrl = $scope.siteURL + 'collections/json_get_collection_detail_by_id';
                collectionUrl += '/' + col.collection_id;
                $http.get(collectionUrl).success(function(result)
                {
                    $scope.showWaitForm = false;
                    $scope.currentCollection = result;                    
                    $scope.calculateTotalFees();
                });
            }
            else
            {
                var url = $scope.siteURL + 'collections/json_create_new_collection';
                url += "/" + col.student_id + "/" 
                    + $scope.selectedClass + "/" 
                    + $scope.selectedYear.replace("/", "and") + "/"
                    + $scope.selectedTypeId;
                
                $http.get(url).success(function(result)
                {
                    $scope.showWaitForm = false;
                    $scope.currentCollection =  result;
                });
            }
            
            $scope.canAddNewfee = false;
        };
        
        $scope.calculateTotalFees = function()
        {
            var total = 0;
            for(var i = 0; i < $scope.currentCollection.fees.length; i++)
            {
                 total = 1*total + 1*$scope.currentCollection.fees[i].amount;
            }
            $scope.currentCollection.totalFeesPaid = total;
        }
        
        
        $scope.addFee = function()
        {
            $scope.newFee = $scope.newFee.replace(/\D/g, '');
            if(isNaN($scope.newFee) || !$scope.newFee > 0)
            {
                alert('You must provide a valid CFA number');
            }
            else
            {
                var newFeeObj = {
                'transaction_id':0,
                'collection_id' : $scope.currentCollection.collection_id,
                'amount':$scope.newFee,
                'collection_type_id':$scope.currentCollection.type_id,
                'is_input':'1',
                'date_recorded':new Date() | 'date: dd MMM yyyy HH:mm',
                'date_recorded_iso':new Date(),
                'recorded_by_user_id':$scope.currentUser.user_id,
                'recorded_by':$scope.currentUser.full_name
                 };
           
                $scope.currentCollection.fees.push(newFeeObj);
                
                $scope.canAddNewfee = false;
            }
            
           $scope.newFee = null;
           
           $scope.calculateTotalFees();
        };  
        
        
            
        $scope.removeFee = function(feeToRemove)
        {
           $scope.currentCollection.fees.splice($scope.currentCollection.fees.indexOf(feeToRemove), 1);
           $scope.calculateTotalFees();
        };
        
        
        $scope.deleteCollection = function()
        {
            $scope.showWaitForm = true;
            $scope.canDelete = false;
            var url = $scope.siteURL + 'collections/delete_collection/';
            url += '/';
            url += $scope.currentCollection.collection_id;
            
            $http.get(url).success(function(result)
            {
                $scope.showWaitForm = false;
                $scope.getCollections();
            });
        };
        
        $scope.saveCurrentCollection = function()
        {
            var url = $scope.siteURL + 'collections/save_collection_json';
            alert("saving");         
            $http({
                method: 'POST',
                url: url,
                data: angular.toJson($scope.currentCollection)
                })
                .success(function (data, status, headers, config) 
                {
                    $scope.getCollections();
                })
                .error(function (data, status, headers, config) 
                {                    
                    alert('an error occured');
                });
        };
})
})();
    
</script>