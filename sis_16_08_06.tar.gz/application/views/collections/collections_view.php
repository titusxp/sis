<div  ng-controller="SearchFeesController as search" ng-init="getCollections()">
    
    
    <!--collection-->
    <div>
    <form name="filterForm" class="form-inline">

        <label>Type: </label>
        <select class="form-control input-sm" ng-model="selectedTypeId" ng-change="collectionTypeChanged()">
            
            <option value="0" disabled=""> 
            </option><option value="0" disabled="">Income Types</option>
            <option ng-repeat="ctype in allIncomeTypes" value="{{ctype.type_id}}">
                {{ctype.type_name}}
            </option>
            
            <option value="0" disabled=""> </option>
            <option value="0" disabled="">Expense Types</option>
            <option ng-repeat="ctype in allExpenseTypes" value="{{ctype.type_id}}">
                {{ctype.type_name}}
            </option>
            
        </select>
        
        <label>Class: </label>
        <select class="form-control input-sm" ng-model="selectedClass" ng-change="getCollections()">
            <option ng-repeat="class in allClasses" value="{{class.class_id}}">
                {{class.class_name}}
            </option>
        </select>


        <label>Academic Year: </label>
        <select class="form-control input-sm" ng-model="selectedYear" ng-change="getCollections()">
            <option ng-repeat="year in allAcademicYears" value="{{year.year_value}}">
                {{year.year_name}}
            </option>
        </select>

        <input type="submit" value="Search" ng-click="getCollections()" class="btn btn-xs btn-primary"/>

        <br/><br/>
    
    </form>
        
    <?php echo_wait_form()?><br>
        
    <table ng-hide="showWaitForm" class="table table-hover table-bordered table-condensed table-striped table-responsive">
        <thead>
        <th>Student</th>
        <th ng-hide="selectedType.is_expense > 0">Amount Due</th>
        <th>{{selectedType.is_expense > 0 ? "Amount Spent": "Total Paid"}}</th>
        <th ng-hide="selectedType.is_expense > 0">Amount Owed</th>
        <th></th>
        </thead>
        <tr ng-show="collectionsEmpty">
            <td colspan="5">No students in the selected class and academic year</td>
        </tr>
        <tr ng-repeat="col in collections">
            <td>{{col.student_name}}</td>
            <td ng-hide="selectedType.is_expense > 0">{{col.amount_due}}</td>
            <td>{{col.amount_paid}}</td>
            <td ng-hide="selectedType.is_expense > 0">{{col.amount_owed}}</td>
            <td>
                <button type="button" class="btn btn-success btn-xs" 
                        ng-click="showCollection(col)" style="width:100%;"
                    data-toggle="modal" data-target="#viewCollection">
                    View
                </button>
            </td>
        </tr>
    </table>
    
    </div>
 
     
   <!--add/edit collection-->
    <div id="viewCollection" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header" ng-show="showWaitForm">
                       <?php echo_wait_form()?><br>                  
                </div>
                
                <div class="modal-body" ng-hide="showWaitForm">
                    <button type="button" class="close" data-dismiss="modal">&times</button>
                    <br/><br/>
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">Collection Info</h3>
                            </div>

                            <div class="panel-body"> 
                                <table class="table table-hover table-bordered table-condensed">
                                    <tr>
                                        <td>Type</td>
                                        <td>{{selectedType.type_name}}</td>
                                    </tr>
                                    <tr>
                                        <td>Student</td>
                                        <td>{{currentCollection.student_name}}</td>
                                    </tr>
                                    <tr>
                                        <td>Class</td>
                                        <td>{{currentCollection.class_name}}</td>
                                    </tr>
                                    <tr>
                                        <td>Academic Year</td>
                                        <td>{{currentCollection.academic_year}}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">{{selectedType.is_expense > 0 ? "Expenditure": "Payments"}}</h3>
                                </div>
                                <div class="panel-body">
                                    <table class="table table-hover table-bordered table-condensed">
                                        <a href="#" ng-model="canAddNewfee" ng-click="canAddNewfee=!canAddNewfee">
                                            Add
                                        </a><br>
                                 
                                        <input type="text" ng-model="newFee" ng-show="canAddNewfee"  ng-change="allowOnlyNumbers()" />
                                        <button ng-click="addFee()" ng-show="canAddNewfee">Add</button>
                                
                                    <thead class="thead-default">
                                        <td>Date</td>
                                        <td>Recorded By</td>
                                        <td>Amount Paid</td>
                                        <td></td>
                                    </thead>
                                    <tr ng-repeat="fee in currentCollection.fees">
                                        <td>{{fee.date_recorded_iso|date:'dd MMM yyyy, hh:mm'}}</td>
                                        <td>{{fee.recorded_by}}</td>
                                        <td class="text-right">{{fee.amount}} CFA</td>
                                        <td>
                                            <button type="button" class="close"  ng-click="removeFee(fee)">&times</button>
                                        </td>
                                    </tr>
                                    <tr style="background-color: #000; color: #fff">
                                        <td></td>
                                        <td>Total Paid</td>
                                        <td class="text-right">{{currentCollection.totalFeesPaid}} CFA</td>
                                        <td></td>
                                    </tr>
                                    
                                </table>
                                    
                                </div>
                            </div>

                    <span ng-hide="selectedType.is_expense > 0">
                        Amount Due = {{currentCollection.amount_due}} ,
                        Total Paid = {{currentCollection.totalFeesPaid}} ,
                        Amount Owed = {{currentCollection.amount_due - currentCollection.totalFeesPaid - currentCollection.totalDeductions}} ,
                    </span>
                    
                    <span ng-show="selectedType.is_expense > 0">
                        Total Spent = {{currentCollection.totalFeesPaid}}
                    </span>
                    <hr>
                    <button type="submit" ng-click="saveCurrentCollection()" 
                            class="btn btn-xs btn-success" data-dismiss="modal">
                        Save All Changes</button>
                    
                    <button type="submit" ng-click="canDelete = true" 
                            ng-show="currentCollection.collection_id > 0"
                            class="btn btn-xs btn-danger" >
                        Delete this</button>
                    
                    <div class="alert alert-danger" ng-show="canDelete===true">
                        This will not only delete 
                        this entire record but also any records of payments associated with it.
                        Are you sure?
                        <button class="btn btn-primary btn-xs" data-dismiss="modal" 
                                ng-click="deleteCollection()">
                            Yes
                        </button>
                        <button class="btn btn-danger btn-xs" ng-click="canDelete = !canDelete">
                            No
                        </button>
                    </div>
                            
                
                </div>
            </div>
            <div class="modal-footer">&nbsp;</div>
        </div>
    </div>
</div>




