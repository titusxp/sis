<div ng-controller="testController">
    
    <p ng-repeat="n in collections">
        academic year = {{n.academic_year}} <br>
        amount_due = {{n.amount_due}} <br>
        amount_owed = {{n.amount_owed}} <br>
        amount_paid = {{n.amount_paid}} <br>
        academic_year = {{n.academic_year}} <br>
    </p>
    
</div> 
