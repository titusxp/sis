<?php

 echo '<div class = "error_label">' . $error_message . '</div>'. '<br />';
 echo anchor($redirect_link, "OK");

