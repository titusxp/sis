This project is a web based School Information System I built for a school in Cameroon.
It keeps track of
- Students basic info
- School Fee payments info
- Staff Salaries payments
- Scholarship awards to students
- etc.
