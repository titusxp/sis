$(document).ready(function(){
    $('#date_field').datepicker({
        format: "dd M yyyy",
        startView: 2,
        clearBtn: true,
        calendarWeeks: true,
        autoclose: true,
        todayHighlight: true
    });

});

